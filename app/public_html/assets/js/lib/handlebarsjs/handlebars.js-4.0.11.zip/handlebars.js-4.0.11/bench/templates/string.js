module.exports = {
  context: {},
  handlebars: 'Hello world',
  dust: 'Hello world',
  mustache: 'Hello world',
  eco: 'Hello world'
};
